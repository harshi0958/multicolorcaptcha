
# fontlibrary.org

The fonts on this directories comes from [https://www.fontlibrary.org](https://fontlibrary.org/es/search?lang=&category=&license=OFL+(SIL+Open+Font+License) website.
